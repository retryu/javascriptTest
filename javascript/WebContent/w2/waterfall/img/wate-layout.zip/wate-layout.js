var globalConfig = {
	lastId: <?=$lastId?>,
	cachedImgItems: [],
	maxHeight: 0,
	columnCount: 4,
	baseUrl: '/userupload/'
};
var Column = function(order){
	this.order = order;
	this.maxHeight = 0;
	this.columnWidth = 230;
	this.left = this.columnWidth * order;
	this.lastItem = null;
	this.positioned = false;
	this.setReferItem = function(item){
		this.lastItem = item;
	}
	
	this.getHeight = function(){
		if(this.lastItem){
			this.maxHeight = this.lastItem.getBottom();
		}
		return this.maxHeight;
	}
	
	this.getLeft = function(){
		return this.left;
	}
};

var ImgItem = function(referNode, column){
	this.referNode = referNode;
	this.bottom = -1;
	this.positioned = false;
};

ImgItem.prototype = {
	/*
	 *set the refer node's top
	 * @param value: Number
	 */
	setTop: function(value){
		this.referNode.style.top = value + 'px';
	},
	/*
	 *set the refer node's left
	 * @param value: Number
	 */
	setLeft: function(value){
		this.referNode.style.left = value + 'px';
	},
	/*
	 *get the refer node bottom position
	 */
	getBottom: function(){
		if(this.positioned){
			if(this.bottom < 0){
				this.bottom = parseInt(this.referNode.style.top) + this.referNode.clientHeight;
			}
			return this.bottom;
		}else{
			throw("current node has not been positioned!");
		}
	},
	setPosition: function(column){
		this.positioned = true;
		this.setLeft(column.getLeft());
		this.setTop(column.getHeight() + 10);
		column.setReferItem(this);
	}
};

var layouter = {
	config: globalConfig,
	columns: [],
	cachedItems: [],
	isRequesting : false,
	init: function(){
		//init the columns
		for(var i = 0, len = this.config.columnCount; i < len; i++){
			this.columns.push(new Column(i));
		}
		
		var liItems = document.getElementById('img_list').getElementsByTagName('li');
		
		for(i = 0, len = liItems.length; i < len; i++){
			this.addNewItem(liItems[i]);
		}
		
		this.initEvents();
	},
	
	initEvents: function(){
		window.onscroll = function(e){
			var docSize = dk.getDocSize();
			var scroll = dk.getScroll();
			var browserSize = dk.getBrowserSize();
			if(docSize.height - browserSize.height < scroll.top + 100){
				layouter.loadNext();
			}
			
			if(scroll.top > 0){
				dk.$('btn_top').style.display = 'block';
			}else{
				dk.$('btn_top').style.display = 'none';
			}
		}
	},
	
	getMinHeightColumn: function(){
		var minHeight = -1, tempColumn = null;
		
		for(var i = 0,len = this.columns.length; i < len; i++){
			if(minHeight > this.columns[i].getHeight() || minHeight == -1){
				minHeight = this.columns[i].getHeight();
				tempColumn = this.columns[i];
			}
		}
		
		return tempColumn;
	},
	
	getMaxHeight: function(){
		var maxHeight = -1;
		for(var i = 0, len = this.columns.length; i < len; i++){
			if(maxHeight < this.columns[i].getHeight()){
				maxHeight = this.columns[i].getHeight();
			}
		}
		
		return maxHeight;
	},
	addNewItem: function(liItem){
		var imgItem = new ImgItem(liItem);
		imgItem.setPosition(this.getMinHeightColumn());
		this.cachedItems.push();
		
		document.getElementById('img_list').style.height = this.getMaxHeight() + 'px';
	},
	loadNext: function(){
		if(!layouter.isRequesting){
			layouter.isRequesting = true;
			new Request({url: 'get-next.php?lastid=' + globalConfig.lastId, dataType: 'json', success: function(data){
				globalConfig.lastId = data.lastId;
				for(var j = 0, len = 10; j < len; j++){
					var imgData = data.images[j];
					var tempImg = document.createElement('img');
					tempImg.width =imgData.width;
					tempImg.height = imgData.height;
					tempImg.src = globalConfig.baseUrl + '200/' + imgData.filename;
					var tempA = dk.$c('a');
					tempA.href = globalConfig.baseUrl + 'orig/' + imgData.filename;
					tempA.target = "_blank";
					tempA.appendChild(tempImg);
					var tempDiv = dk.$c('div');
					tempDiv.appendChild(tempA);
					var btnsDiv = dk.$c('div', null, 'btns_box');
					btnsDiv.imgid=imgData.id;
					var titleDiv = dk.$c('div', null, 'title_box');
					btnsDiv.innerHTML = '<span class="btn_like">喜欢(' + imgData.like_count + ')</span> / <span class="btn_unlike">不喜欢(' + imgData.unlike_count + ')</span>';
					titleDiv.innerHTML = imgData.title;
					var current = document.createElement('li');
					current.appendChild(tempDiv);
					current.appendChild(btnsDiv);
					current.appendChild(titleDiv);
					dk.$('img_list').appendChild(current);
					layouter.addNewItem(current);
					layouter.isRequesting = false;
				}
			}}).send();
			
		}
	}
};
layouter.init();

dk.addEvent('img_list', 'click', function(e){
	var target = e.target;
	if($$(target).hasClass('btn_like') || $$(target).hasClass('btn_unlike')){
		var imgId = target.parentNode.getAttribute('imgid') ? target.parentNode.getAttribute('imgid') : target.parentNode.imgid;
		var type = '';
		if($$(target).hasClass('btn_like')){
			type = 'like';
		}else{
			type = 'unlike';
		}
		
		new Request({url: 'user-preference.php?type=' + type + '&id=' + imgId, dataType: 'json', success: function(data){
			if(data.status){
				target.innerHTML = data.responseText;
			}
		}}).send();
	}
});